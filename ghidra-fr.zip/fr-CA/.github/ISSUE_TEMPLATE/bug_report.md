---
name: Rapport de bogue
about: Créer un rapport a fin d'améliorer le produit
title: ''
labels: Le Bugue
assignees: ''
---

**La description du Boug.** Une description claire et concise du bogue.

**Reproduire** La procédure suivie pour reproduire le problème :

1. Aller à <<...>>
2. Cliquez sur «... »
3. Faites défiler jusqu'à «... »
4. Voir erreur

**Comportement prévu** Une description claire et concise de ce que vous attendez.

**Captures d'écran** Si applicable, ajoutez des captures d'écran pour aider avec l'explanation de votre problème.

**Pièces jointes** Si applicable, veuillez joindre des fichiers qui ont causé des problèmes ou des fichiers log générés par le logiciel.

**Environnement (veuillez remplir les informations suivantes) :**

- OS: [ex. macOS 10.14.2]
- La Version de Java : [p. ex. 11,0]
- Version Ghidra : [ex. 9.0]

**contexte supplémentaire** Ajouter toute autre information concernant le problème.