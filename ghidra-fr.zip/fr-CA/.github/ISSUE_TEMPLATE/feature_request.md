---
name: Demande de fonctionnalité
about: Suggérer une idée pour ce projet
title: ''
labels: Amélioration
assignees: ''
---

**Votre demande de fonctionnalité est-elle liée à un problème ? Veuillez décrire.** Une description claire et concise de la nature du problème. Ex. Je suis toujours frustré quand [...]

**Veuillez décrire la solution pour la quelle vous recherchez** Une description claire et concise de ce que vous attendez.

**Veuillez décrire les alternatives que vous avez considerées** Une description claire et concise de toute autre solution ou fonctionnalité que vous avez envisagée.

**Contexte supplémentaire** Ajoutez toute autre information concernant le problème.