# Guide des contributeurs

Ghidra est un projet open source. Si vous êtes intéressé à l'améliorer, il y a de nombreuses de façons de contribuer. Par exemple, vous pouvez:

- Soumettre un rapport de bogue
- Suggérer une nouvelle fonctionnalité
- Veuillez fournir des commentaires sur les demandes/propositions
- Proposer un patch en soumettant une demande de traction
- Suggérer ou proposez des améliorations de la documentation
- Examiner les demandes de traction exceptionnelle
- Répondre aux questions des autres utilisateurs
- Partager le logiciel avec d’autres utilisateurs qui sont intéressés
- Enseigner aux autres à utiliser ce logiciel
- Paquet et distribution du logiciel communautaire en aval (comme votre distribution Linux préférée)

## Bogues et demandes de fonctionnalités

Si vous pensez que vous avez trouvé un bogue ou que vous voulez proposer une nouvelle fonctionnalité, Veuillez rechercher, tout d’abord, les[questions](https://github.com/NationalSecurityAgency/ghidra/issues) (FAQ) pour vérifier s'il a déjà été déclaré. Si vous ne pounez pas trouver un problème existant, veuillez essayer utiliser un des modèles fournis pour créer une nouvelle tâche et de fournir plus de détailles que possible va aider avec la reproduction du bogue ou la explanation de votre fonctionnalité proposée.

## Conseils de présentation patch

Les correctifs doivent être soumis sous la forme de << Fusiodemande>> au Ghidra [repository](https://github.com/NationalSecurityAgency/ghidra/) sur GitHub. D'abord, considérez les astuces suivantes pour assurer un processus efficace lors de l'envoi d'un correctif :

- Assurez-vous que le correctif compile et ne casse aucun test de compilation
- Soyez compréhensif, patient et sympathique. Les développeurs pourrait avoir besoin du temps supplementaries pour revoir vos soumissions avant qu'ils puissent prendre action ou donner ou réponse. Cela ne signifie pas votre contribution n'est pas important à nous. Si votre contribution n'a pas reçu un réponse dans un délai raisonnable, veuillez nous envoyer une enquête polie pour une mise à jour.
- Limitez vos correctifs au moindre changement raisonnable pour atteindre votre objectif prévu. Par exemple, ne changez pas d'indentation inutile ; mais ne pas aller de votre façon pour rendre le correctif si minimal qu'il n'est pas facile de lire, non plus. Considérez la perspective du réviseur.
- Avant de soumettre, veuillez écraser vos commits pour utiliser un message qui démarre avec le numéro de problème et une description des changements.
- Isolater plusieurs de patches les uns des autres. Si vous désirez faire plusieurs correctifs indépendants, faites-le dans une manière avec des demandes de tractions séparées(plus petite que vous pourrez revu plus facilement).
- Soyez prêt à répondre aux questions des réviseurs. Ils peuvent avoir questions supplémentaires avant d'accepter votre patch, et peuvent même proposer des modifications. Veuillez accepter ce commentaire d'une manière constructive, et non pas comme un rejet de votre changement proposé.

## Révision

- Nous nous félicitons des révisions de code de n’importe qui. Un committer est obligé d'accepter et de fusionner les modifications.
- Les réviseurs rechercheront des choses comme les problèmes de threading, les implications de performance, la conception de l'API, la duplication des fonctionnalités existantes, la lisibilité et le style de code, l'évitement de bloat (scope-creep), etc.
- Les réviseurs poseront probablement des questions pour mieux comprendre votre changement.
- Les réviseurs feront des commentaires sur les modifications concernant votre patch : 
    - OBLIGIÉ signifie que le changement est requis
    - DEVRAIT signifie que le changement est suggéré, délibérations dans le futur sur le sujet peuvent être exigée
    - POURRAIT signifie que le changement est facultatif

## Le Démarrage

Une fois disponible, veuillez consulter le guide [développeur](DevGuide.md) pour obtenir des instructions pour configurer un environnement de développement approprié.

## Juridiques

Conformément à la section D.6 des Conditions d'utilisation de GitHub à compter de 2019 et de la section 5. de la licence Apache, version 2.0, le responsable du projet pour ce projet accepte les contributions en utilisant le modèle inbound=outbound. Lorsque vous soumettez une demande d'extraction à ce dépôt (entrant), vous acceptez de concéder votre contribution sous les mêmes termes que ceux indiqués dans <LICENSE> (sortant).

Ghidra est un projet d'une nature open source. Les contributions que vous faites à ce dépôt public du gouvernement américain ("USG") sont entièrement volontaires. Lorsque vous soumettez un problème, un rapport de bogue, une question, une amélioration, une demande de tirage, etc., vous offrez votre contribution sans attente de paiement, vous renoncez expressément à toute réclamation de paiement future contre l'USG liée à votre contribution, et vous reconnaissez que cela ne crée aucune obligation de la part de l'USG de quelque nature que ce soit. De plus, votre contribution à ce projet ne crée pas de relation employeur-employé entre le gouvernement américain et le contributeur.