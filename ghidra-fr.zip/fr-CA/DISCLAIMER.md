# Avertissement de garantie

Ce travail est fourni « tel quel ». aucune garantie expresse ou implicite, y compris mais sans s’y limiter, les garanties implicites de qualité marchande et d’adequation a un usage particulier sont exclues. En aucun cas le gouvernement des États-Unis sera responsable pour tout dommage direct, indirect, indirect, spécial, exemplaire ou consécutif (y compris, mais non limité à, des achats de marchandises de remplacement ou de services, de la perte de données ou de profits ou entreprise interruption) a cependant provoqué et sur toute théorie de responsabilité, que ce soit dans le contrat, responsabilité stricte ou délictuelle (y compris la négligence ou autre) résultant de l’utilisation de ce travail, même si avisé de la possibilité de tels dommages.

L'Utilisateur de ce Travail s'engage à tenir inoffensifs et à indemniser le gouvernement des États-Unis, ses agents et ses employés de toute réclamation ou responsabilité (qu'il s'agisse d'une infraction ou d'un contrat), y compris les frais d'avocat, les frais de justice et les dépenses, résultant directement de l'utilisation du produit, y compris, mais sans s'y limiter, les réclamations ou les passifs faits pour dommages ou décès du personnel de l'utilisateur ou de tiers, les dommages à la propriété de l'utilisateur ou de tiers, ainsi que les violations de la propriété intellectuelle ou des droits de données techniques.

# Avertissement de l'atteinte

Rien dans ce travail ne vise à constituer un soutien, explicite ou implicite, par le gouvernement des États-Unis d'un produit ou service de quelque fabricant particulier.

Référence aux produits, processus ou service commerciaux spécifiques par nom commercial, marque de commerce, fabricant ou autre, dans ce Travail ne constitue pas un endossement, une recommandation ou un favori par le gouvernement des États-Unis et ne doit pas être utilisé à des fins de publicité ou d'approbation de produits.